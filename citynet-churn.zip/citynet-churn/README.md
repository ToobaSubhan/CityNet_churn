# CityNet churn baseline

## User story
As the retention manager, I want a weekly list of the 100 customers most likely to cancel next month, so my team can call them first.

## How to run
    pip install -r requirements.txt
    python src/lab7_save.py                       # train and save the pipeline
    python src/predict.py data/new_customers.csv  # writes reports/predictions.csv

The step-by-step analysis is in `notebooks/churn_lab.ipynb` (run it from the `notebooks/` folder).

## Results (validation, then test once)
Split: 60% train / 20% validation / 20% test, stratified, random_state=42. Model chosen on validation only; test read once.
Validation and test each hold 1,000 customers and about 179 churners (17.9%).

| Metric | Baseline (rule score) | Our model (logistic regression) |
|---|---|---|
| PR-AUC, validation | 0.274 | 0.383 |
| Churners in top 100, validation | 30 | 48 |
| PR-AUC, test (once) | 0.268 | 0.402 |
| Churners in top 100, test (once) | 35 | 51 |

Random ranking would give PR-AUC of about 0.18 and about 18 churners in the top 100.
The baseline is a hand-written score: +1 for a late last bill, +1 for no auto-pay, +1 for cash payment.
A gradient boosting model was also tried and lost to logistic regression on validation (PR-AUC 0.345, 41 in top 100).

## Intended use
Rank current customers by churn probability each week so the retention team knows whom to call first. The ranking is a prioritisation aid, and a person decides whom to contact.

## Not for
- Deciding pricing, service levels or denying service to individual customers.
- Use on another market, billing system or time period without retraining and re-testing.
- Treating the probabilities as calibrated or as explanations of why someone leaves.

## Assumptions
- Features reflect the 90 days before the prediction date and the label is cancellation in the following month, so there is no overlap in time.
- `cancel_request_logged` is excluded. It is 95.8% churn when set, it is missing from `new_customers.csv`, and it would only be known once the customer has already signalled leaving. Including it gives test PR-AUC of about 0.90, which is not achievable in real use.
- The weekly pool is similar in churn rate (about 18%) to this data. In a larger pool, "top 100" is a smaller share and precision in the top 100 would likely be higher.

## Risks and limitations
- The data is made up for the course, so real churn drivers and base rates will differ.
- Only about 40% of the top 100 are true churners (51 on test). Most calls would go to customers who would have stayed.
- Test metrics come from 1,000 rows and about 179 churners, so they carry noise of a few churners in the top 100. The gap over the baseline is meaningful, but small differences between models are not.
- Tenure, outages, support calls and auto-pay carry most of the signal. These are associations and do not show that changing them would reduce cancellations.
- `new_customers.csv` has 8 rows, which only checks that the pipeline runs end to end.
- Age (8.2%) and payment method (3.0%) have missing values, filled with the training median and a "missing" category.
