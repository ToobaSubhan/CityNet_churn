# Data card: citynet_churn.csv

- Source: CityNet customer records (made-up data for this course)
- Rows: 5,000   Columns: 14
- One row is: one customer, measured over the last 90 days
- Target: `churned` = 1 if the customer cancelled in the next month. Share of 1s: 17.92% (896 of 5,000)
- Missing values: `age` 411 (8.2%), `payment_method` 149 (3.0%). No other column has missing values. No duplicate customer_id.
- Columns NOT used, and why:
  - `customer_id`: unique identifier, carries no signal.
  - `cancel_request_logged`: leaks the target. 759 of 792 customers with the flag churned (95.8%) against 137 of 4,208 without (3.3%). It is also absent from `new_customers.csv`, so it cannot be used when scoring.
  - `churned`: the target.
- Known issues:
  - Synthetic data, so real-world rates and drivers will differ.
  - Cash payers (27.8%), customers without auto-pay (22.8%) and late payers (28.0%) churn more, and these groups likely overlap.
  - Regions and plans are uneven in size (Central 745 rows, Fiber 100 730 rows), so their churn rates are noisy.
  - `new_customers.csv` has only 8 rows and no labels.
