"""Usage: python src/predict.py data/new_customers.csv  -> writes reports/predictions.csv"""
import sys
import joblib
import pandas as pd
from pathlib import Path
from common import FEATURES

ROOT = Path(__file__).resolve().parents[1]
path = sys.argv[1] if len(sys.argv) > 1 else ROOT / "data" / "new_customers.csv"

df = pd.read_csv(path)
missing = [c for c in FEATURES if c not in df.columns]
if missing:
    raise SystemExit(f"Input is missing columns: {missing}")

model = joblib.load(ROOT / "models" / "churn_pipeline.joblib")
out = df[["customer_id"]].copy()
out["churn_probability"] = model.predict_proba(df[FEATURES])[:, 1]
out = out.sort_values("churn_probability", ascending=False).head(100)
out.insert(0, "rank", range(1, len(out) + 1))

(ROOT / "reports").mkdir(exist_ok=True)
out.to_csv(ROOT / "reports" / "predictions.csv", index=False)
print(f"Wrote reports/predictions.csv ({len(out)} rows)")
