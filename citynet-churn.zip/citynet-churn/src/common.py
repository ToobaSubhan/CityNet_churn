import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.svm import SVC

TARGET = "churned"
# Dropped on purpose:
#  customer_id           -> unique identifier, no signal
#  cancel_request_logged -> leaks the target (95.8% of those customers churn) and is
#                           absent from new_customers.csv, so it can't be used at prediction time
DROP = ["customer_id", "cancel_request_logged", TARGET]
CAT = ["region", "plan", "tv_bundle", "payment_method", "auto_pay", "paid_late_last_bill"]
NUM = ["monthly_bill", "tenure_months", "support_calls_90d", "outage_hours_90d", "age"]
FEATURES = CAT + NUM


def make_preprocessor(scale=False):
    num_steps = [("imp", SimpleImputer(strategy="median"))]
    if scale:
        num_steps.append(("sc", StandardScaler()))
    cat = Pipeline([
        ("imp", SimpleImputer(strategy="constant", fill_value="missing")),
        ("oh", OneHotEncoder(handle_unknown="ignore")),
    ])
    return ColumnTransformer([("num", Pipeline(num_steps), NUM), ("cat", cat, CAT)])


def make_logreg():
    return Pipeline([("prep", make_preprocessor(scale=True)),
                     ("clf", LogisticRegression(max_iter=1000, class_weight="balanced"))])


def make_gbm(**kw):
    params = dict(learning_rate=0.05, max_iter=200, max_depth=3, random_state=42)
    params.update(kw)
    return Pipeline([("prep", make_preprocessor()),
                     ("clf", HistGradientBoostingClassifier(**params))])


def make_svm(kernel="rbf", C=10, gamma=0.01):
    # SVMs need scaled numbers. probability=True adds Platt scaling so predict_proba works.
    return Pipeline([("prep", make_preprocessor(scale=True)),
                     ("clf", SVC(kernel=kernel, C=C, gamma=gamma, class_weight="balanced",
                                 probability=True, random_state=42))])


def churners_in_top_k(y_true, scores, k=100):
    order = np.argsort(-np.asarray(scores), kind="stable")[:k]
    return int(np.asarray(y_true)[order].sum())
