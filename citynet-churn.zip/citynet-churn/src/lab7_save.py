"""Train the CityNet churn pipeline and save it to models/churn_pipeline.joblib."""
import joblib
import pandas as pd
from pathlib import Path
from sklearn.metrics import average_precision_score
from sklearn.model_selection import train_test_split
from common import FEATURES, TARGET, make_svm, churners_in_top_k

ROOT = Path(__file__).resolve().parents[1]

df = pd.read_csv(ROOT / "data" / "citynet_churn.csv")
X, y = df[FEATURES], df[TARGET]

# 60/20/20 split: train / validation / test (test is touched once, at the end)
X_tmp, X_test, y_tmp, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
X_train, X_val, y_train, y_val = train_test_split(X_tmp, y_tmp, test_size=0.25, stratify=y_tmp, random_state=42)

model = make_svm().fit(X_train, y_train)
p_val = model.predict_proba(X_val)[:, 1]
print(f"Validation PR-AUC: {average_precision_score(y_val, p_val):.3f}")

# Refit on train+validation, then read test once
model.fit(X_tmp, y_tmp)
p_test = model.predict_proba(X_test)[:, 1]
print(f"Test PR-AUC: {average_precision_score(y_test, p_test):.3f}")
print(f"Test churners in top 100: {churners_in_top_k(y_test, p_test, 100)} of {int(y_test.sum())}")

# Final model for scoring: fit on all labelled data
model.fit(X, y)
(ROOT / "models").mkdir(exist_ok=True)
joblib.dump(model, ROOT / "models" / "churn_pipeline.joblib")
print("Saved models/churn_pipeline.joblib")